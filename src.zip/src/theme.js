
export const themeColors = () => ({
    palette: {
                primary: {
                    main: "#048BA8",
                    white: "#fff",
                    black: "#000"
                },
                secondary: {
                    main: "#F18F01",
                },
    },
});
