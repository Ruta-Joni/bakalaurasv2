import {Box } from '@mui/material'
import React, { useEffect } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { useDispatch} from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { jobTypeCreateAction } from '../redux/actions/jobTypeAction';

const validationSchema = yup.object({
    jobTypeName: yup
        .string('Įveskite katerogijos pavadinimą')
        .min(3, 'Kategorijos pavadinimas turėtų būti bent 3 simbolių ilgio')
        .required('Kategorijos pavadinimas būtinas'),
});

const JobTypeAddForm = () => {
    const dispatch = useDispatch();

    useEffect(() => {
    }, [])

    const formik = useFormik({
        initialValues: {
            jobTypeName: ''
        },
        validationSchema: validationSchema,
        onSubmit: (values, actions) => {
            dispatch(jobTypeCreateAction(values));
            actions.resetForm();
        }
    })

    return (
        <>
                <Box onSubmit={formik.handleSubmit} component="form">
                    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", width: "400px" }}>
                        <TextField
                            sx={{
                                my: 3,
                                "& .MuiInputBase-root": {
                                    color: 'text.secondary',
                                },
                                fieldset: { borderColor: "rgb(231, 235, 240)" }
                            }}
                            fullWidth
                            id="jobTypeName"
                            label="Tipas"
                            name='jobTypeName'
                            InputLabelProps={{
                                shrink: true,
                            }}

                            placeholder="Tipas"
                            value={formik.values.jobTypeName}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            error={formik.touched.jobTypeName && Boolean(formik.errors.jobTypeName)}
                            helperText={formik.touched.jobTypeName && formik.errors.jobTypeName}
                        />
                        <Button fullWidth variant="contained" type='submit' >Pridėti</Button>
                    </Box>
                </Box>
        </>
    )
}

export default JobTypeAddForm