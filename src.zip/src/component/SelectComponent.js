import * as React from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useSelector } from 'react-redux';
import { useTheme } from '@emotion/react';

const SelectComponent = ({handleChangeCategory}) => {
    const { jobType } = useSelector(state => state.jobTypeAll);
    let data = [];
    data = (jobType !== undefined && jobType.length > 0) ? jobType : []
    
    const { palette } = useTheme();
    return (
        <Box sx={{ minWidth: 120 }}>
            <FormControl fullWidth>
                <InputLabel>Sritis</InputLabel>
                <Select
                    inputProps={{
                        MenuProps: {
                            MenuListProps: {
                                sx: {
                                    backgroundColor: palette.primary.white
                                }
                            }
                        }
                    }}
                    id="jobType"
                    name="jobType"
                    label="Tipas"
                    onChange={handleChangeCategory}
                >
                    {data.map((categ) => <MenuItem value={categ._id}>{categ.jobTypeName}</MenuItem>)}
                </Select>
            </FormControl>
        </Box>
    )
}

export default SelectComponent