import * as React from 'react';
import MenuItem from '@mui/material/MenuItem';
import { ListItemIcon } from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { Link, useParams } from 'react-router-dom'
import { useTheme } from '@emotion/react';

const SideComponent = ({linkas, title}) => {
   
    
    const { palette } = useTheme();
    return (
        <>
         <MenuItem>
                <LocationOnIcon sx={{ color: palette.secondary.main, fontSize: 18 }} />
            <Link style={{ color: palette.primary.black, textDecorationLine:"none" }} to={linkas}>{title}</Link>
        </MenuItem>
        </>
       
    )
}

export default SideComponent