import { Box } from '@mui/material';
import React from 'react'
import HeaderTop from './HeaderTop';
import Footer from '../../component/Footer';

const Layout = (Component) => ({ ...props }) => {

    return (
        <>
            
                <Box sx={{ width: "100%", bgcolor: "#ffffff", height:"100%"}}>
                    <HeaderTop sx={{height:"10%"}}/>
                    <Box sx={{ p: 3, height:"80vh"}}>
                        <Component sx={{}} {...props} />
                    </Box>
                    <Footer sx={{height:"10%"}}/>
                </Box>
            
        </>
    )
}

export default Layout