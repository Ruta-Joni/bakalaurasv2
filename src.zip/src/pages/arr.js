const structure = ['HeaderTop', 'AdminDashboard','TabsForDashboard', 'Footer'];
   export default structure;