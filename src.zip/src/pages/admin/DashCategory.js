import React, { useEffect } from 'react'
import { Box, Button, Paper } from '@mui/material'
import { useDispatch, useSelector } from 'react-redux';
import { jobTypeDeleteAction, jobTypeLoadAction } from '../../redux/actions/jobTypeAction';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import moment from 'moment'
import JobTypeAddForm from '../../component/JobTypeAddForm';
import AddElement from '../../component/AddElement';
import DeleteIcon from '@mui/icons-material/Delete';
const DashCategory = () => {


    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(jobTypeLoadAction())
    }, []);


    const { jobType, loading } = useSelector(state => state.jobTypeAll);
    let data = [];
    data = (jobType !== undefined && jobType.length > 0) ? jobType : []

    const deleteJobCategoryById = (e, id) => {
        e.preventDefault();
        dispatch(jobTypeDeleteAction(id));
        dispatch(jobTypeLoadAction());
    }

    return (
        <>
        <Box >
        <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="caption table">
                <caption>
                <Box sx={{ pb: 2, display: "flex", justifyContent: "right" }}>
                    <AddElement buttonName="Pridėti tipą" formToAdd={<JobTypeAddForm></JobTypeAddForm>} />
                </Box>
                </caption>
                <TableHead>
                <TableRow>
                    <TableCell align='left'>ID</TableCell>
                    <TableCell align="left">Kategorija</TableCell>
                    <TableCell align="left">Sukurta</TableCell>
                </TableRow>
                </TableHead>
                <TableBody>
                {data.map((data) => (
                    <TableRow key={data.name}>
                    <TableCell align='left'>
                        {data._id}
                    </TableCell>
                    <TableCell align="left">{data.jobTypeName}</TableCell>
                    <TableCell align="left">
                    {moment(data.createdAt).format('YYYY-MM-DD HH:MM:SS')}
                    </TableCell>
                    <TableCell align="right">
                    <Box >
                        <Button onClick={(e)=>deleteJobCategoryById(e,data._id)} variant="contained" color="error"><DeleteIcon></DeleteIcon></ Button>
                    </Box>
                    </TableCell>
                    </TableRow> 
                ))}
                </TableBody>
            </Table>
            </TableContainer>
        </Box>

        
    </>
    )
}

export default DashCategory