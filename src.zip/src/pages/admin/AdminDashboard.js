import { Box, Stack, Typography } from '@mui/material';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import WorkIcon from '@mui/icons-material/Work';
import CategoryIcon from '@mui/icons-material/Category';
import { useTheme } from '@mui/material'
import TabsForDashboard from './TabsForDashboard.js';
import {useDispatch, useSelector } from 'react-redux';
import { jobLoadAction } from '../../redux/actions/jobAction';
import StatComponent from '../../component/StatComponent.js';
import React, { useEffect } from 'react'
import {jobTypeLoadAction } from '../../redux/actions/jobTypeAction';


const AdminDashboard = () => {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(jobLoadAction())
    }, []);
    useEffect(() => {
        dispatch(jobTypeLoadAction())
    }, []);
    
    const { palette } = useTheme();
    const { users, loading } = useSelector(state => state.allUsers);
    let { jobs, loading1} = useSelector(state => state.loadJobs);
    const { jobType, loading2 } = useSelector(state => state.jobTypeAll);
    let jobData = (jobs !== undefined && jobs.length > 0) ? jobs : []
    let jobTypeData = (jobType !== undefined && jobType.length > 0) ? jobType : []
    return (
        <>
            <Box>
                <Typography variant="h4" sx={{ color: palette.primary.main, fontWeight:600, pb: 3 }}>
                    Administratoriaus aplinka
                </Typography>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    spacing={{ xs: 1, sm: 2, md: 4 }}
                >
                     <StatComponent
                        value={users.length}
                        icon={<SupervisorAccountIcon sx={{fontSize: 30}} />}
                        description="Vartotojų sistemoje"
                    />
                    <StatComponent
                        value={jobData.length}
                        icon={<WorkIcon sx={{fontSize: 30}} />}
                        description="Darbo skelbimų"
                    />
                    <StatComponent
                        value={jobTypeData.length}
                        icon={<CategoryIcon sx={{fontSize: 30}} />}
                        description="Darbo sričių"
                    />
                </Stack>
            </Box>
            
        </>

        
    )
}

export default AdminDashboard