import React, { useEffect } from 'react'
import { Box, Button, Paper } from '@mui/material'
import { useDispatch, useSelector } from 'react-redux';
import { jobLoadAction, jobDeleteAction } from '../../redux/actions/jobAction';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import DeleteIcon from '@mui/icons-material/Delete';
import JobAddForm from '../../component/JobAddForm';
import AddElement from '../../component/AddElement';

const DashJobs = () => {


    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(jobLoadAction())
    }, []);


    const { jobs, loading } = useSelector(state => state.loadJobs);
    let data = [];
    data = (jobs !== undefined && jobs.length > 0) ? jobs : []


    //delete job by Id
    const deleteJobById = (e, id) => {
        e.preventDefault();
        dispatch(jobDeleteAction(id));
        dispatch(jobLoadAction());
    }

    return (
            <Box >
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="caption table">
                    <caption>
                    <Box sx={{ pb: 2, display: "flex", justifyContent: "right" }}>
                    <AddElement buttonName="Pridėti skelbimą" formToAdd={<JobAddForm></JobAddForm>} />
                    </Box>
                    </caption>
                    <TableHead>
                    <TableRow>
                        <TableCell align='left'>Darbo pavadinimas</TableCell>
                        <TableCell align="left">Kategorija</TableCell>
                        <TableCell align="left">Įkėlė vartotojas</TableCell>
                        <TableCell align="left">Alga</TableCell>
                        <TableCell align="right">Veiksmai</TableCell>
                    </TableRow>
                    </TableHead>
                    <TableBody>
                    {data.map((data) => (
                        <TableRow key={data.name}>
                        <TableCell align='left'>
                            {data.title}
                        </TableCell>
                        <TableCell align="left">{data.jobType.jobTypeName}</TableCell>
                        <TableCell align="left">
                            {data.user._id}
                        </TableCell>
                        <TableCell align="left">
                            {data.salary}
                        </TableCell>
                        <TableCell align="right">
                        <Box >
                            <Button onClick={(e)=>deleteJobById(e,data._id)} variant="contained" color="error"><DeleteIcon></DeleteIcon></ Button>
                        </Box>
                        </TableCell>
                        </TableRow> 
                    ))}
                    </TableBody>
                </Table>
                </TableContainer>
            </Box>   
    )
}

export default DashJobs