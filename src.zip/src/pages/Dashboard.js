import { Typography, Box } from '@mui/material'
import { Stack } from '@mui/system'
import React from 'react'
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import WorkIcon from '@mui/icons-material/Work';
import { useSelector } from 'react-redux'
import moment from 'moment'
import { useTheme } from '@mui/material'
import HeaderTop from './global/HeaderTop';
import Footer from '../component/Footer';
import AdminDashboard from './admin/AdminDashboard';
import TabsForDashboard from './admin/TabsForDashboard';
import UserDashboard from './user/UserDashboard';
import arr from "./arr.js"

const Dashboard = () =>{
const Components = {
    HeaderTop, 
    Footer,
    AdminDashboard,
    TabsForDashboard,
    UserDashboard
  }
  
const getUserComponents = userAuthLevel => {
     if (userAuthLevel === 'user') {
       return ['HeaderTop', 'UserDashboard', 'Footer']
     }
     else if (userAuthLevel === 'admin'){
        return arr
     }
    }
     
  const userComponents = getUserComponents('admin');
     return (
        <div>
            {userComponents.map(componentName => {
                const Component = Components[componentName];
                return <Component/>
             })}
        </div>
    )
  

}

export default Dashboard