import axios from 'axios';
import { toast } from "react-toastify";
import { 
    JOB_TYPE_LOAD_FAIL,
    JOB_TYPE_LOAD_REQUEST, 
    JOB_TYPE_LOAD_SUCCESS,
    JOB_TYPE_DELETE_FAIL,
    JOB_TYPE_DELETE_REQUEST,
    JOB_TYPE_DELETE_SUCCESS,
    JOB_TYPE_CREATE_FAIL,
    JOB_TYPE_CREATE_REQUEST,
    JOB_TYPE_CREATE_SUCCESS
 } from '../constants/jobTypeConstant';



export const jobTypeLoadAction = () => async (dispatch) => {
    dispatch({ type: JOB_TYPE_LOAD_REQUEST });
    try {
        const { data } = await axios.get('/api/type/jobs');
        dispatch({
            type: JOB_TYPE_LOAD_SUCCESS,
            payload: data
        });
    } catch (error) {
        dispatch({
            type: JOB_TYPE_LOAD_FAIL,
            payload: error.response.data.error
        });
    }
}

export const jobTypeDeleteAction = (jobType) => async (dispatch) => {
    dispatch({ type: JOB_TYPE_DELETE_REQUEST });
    try {
        const { data } = await axios.delete("/api/type/delete/"+jobType);

        dispatch({
            type: JOB_TYPE_DELETE_SUCCESS,
            payload: data
        });
        toast.success("Sritis ištrinta sėkmingai");
    } catch (error) {
        dispatch({
            type: JOB_TYPE_DELETE_FAIL,
            payload: error.response.data.error
        });
        toast.error(error.response.data.error);
    }
}

// add job type
export const jobTypeCreateAction = (type) => async (dispatch) => {
    dispatch({ type: JOB_TYPE_CREATE_REQUEST });
    try {
        const { data } = await axios.post("/api/type/create", type);

        dispatch({
            type: JOB_TYPE_CREATE_SUCCESS,
            payload: data
        });
        toast.success("Sritis pridėta sėkmingai");
    } catch (error) {
        dispatch({
            type: JOB_TYPE_CREATE_FAIL,
            payload: error.response.data.error
        });
        toast.error(error.response.data.error);
    }
}